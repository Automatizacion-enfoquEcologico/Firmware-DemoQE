/* ###################################################################
**     Filename    : main.c
**     Project     : serial2
**     Processor   : MC9S08QE128CLK
**     Version     : Driver 01.12
**     Compiler    : CodeWarrior HCS08 C Compiler
**     Date/Time   : 2018-02-14, 14:22, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.12
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "TI1.h"
#include "AD1.h"
#include "AS1.h"
#include "PWM1.h"
#include "Bit1.h"
#include "PWM2.h"
#include "Bit2.h"
#include "Bit3.h"
#include "Bit4.h"
#include "Bit5.h"
#include "TI2.h"
#include "EInt1.h"
#include "AS2.h"
/* Include shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */

#define retrans_lim 2

unsigned char palabra[8];
unsigned char preambulo = 255;
unsigned char binaria = 0x0;
int cont = 0;
int num = 8;
int estado = 0;
unsigned char basura = 240;
int retrans = 0;
unsigned char ERROR = 0; // son 4 bits, val al final de la trama y su funcion es informar a la PC algun inconveniente

int estado_s = 0; // maquina de estados para recepcion serial

unsigned char luz_pwm = 240; // PTC0
bool aire = FALSE; //salidas PTC2 BIT3
unsigned char adc0 = 0; // lm35 interno PTA0
unsigned char adc1 = 0; // lm35 externo PTA1 
unsigned char pir; //entrada PTA2  BIT2
unsigned char reed; //entrada PTA3 BIT1
unsigned char caudal = 0; // PTD2 INT_EXT

bool riego_a = FALSE;
bool enviado = FALSE;
// variables arduino
bool riego = FALSE; // salida
unsigned char luz_in;
bool higrometro;
unsigned char corriente;

unsigned char data_a [3] = {0x0,0x0,0x0};
unsigned char data_pc [3] = {0x0,0x0,0x0};

void main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/


	PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  
  for(;;){ 	  
	  
	  switch (estado){
	  
	  case 0: // leer entradas
		  palabra[0] = preambulo;
		  
		  //leer data digital binaria  		  
		  pir = !Bit1_GetVal(); 	// pta2
		  reed = !Bit2_GetVal();	// pta3
		  
		  
		  // encapsulo entradas leidas por el Demo
		  
		  palabra[1] = 0; // ENTRADAS DIGITALES	
		  binaria = pir;
		  palabra[1] = binaria|palabra[1];
		  binaria = (reed << 1); 
		  palabra[1] = binaria|palabra[1];

		  
		  // leer entradas analogicas, sensores de temperatura		  
		  AD1_MeasureChan(TRUE, 0);
		  AD1_GetChanValue8(0,&adc0);
		    		 
		  AD1_MeasureChan(TRUE, 1);
		  AD1_GetChanValue8(1,&adc1);
		  		    		  
		  if(adc0 == 255){
			  palabra[2] = 254; 
		  }else
		    {
		      palabra[2] = adc0;
		    }
		  
		  if(adc1 == 255){
			  palabra[3] = 254;
		  }else
		    	{
		    		palabra[3] = adc1;
		    	}
		    		  
		  //Limpio la variable Error
		    	
		  ERROR = 0;
		 
		  palabra[5] = caudal;
		  
		  
		  // salidas del sistema para verificacion de errores
		  palabra[6] = luz_pwm;
		  
		  palabra[7] = 0;
		  binaria = (riego << 7);
		  palabra[7] = palabra[7]|binaria;
		  binaria = (aire << 6);
		  palabra[7] = palabra[7]|binaria;
		    		  
		  break;
	  
	  case 1: // envio arduino y esperar respueta: ERROR = (ERROR|0x04);
		 
		  if(!enviado){ 
		  if(riego){
			  AS2_SendChar(255);
		  }else {
			  AS2_SendChar(240);
		  }
		  enviado = TRUE;
		 }
		  TI2_Enable(); // HABILITAMOS CONTADOR 30ms COMO TTL
  		  break;
	  case 2: // comparo el estado de la salida
		  
		  TI2_Disable();
		  
		 // AS2_Enable();
		  
		  enviado = FALSE;
		 riego_a = data_a[2]&0x01;
		  if(riego_a != riego)
		  {
			  ERROR = (ERROR|0x01);
			  estado = 1;
			  retrans++;
			  if(retrans >= retrans_lim){
				  ERROR = (ERROR|0x02);
				  estado = 3;
			  }
		  }
		  else 
		  {
			  estado = 3;
			  
			  corriente = data_a[1];
			  luz_in = ((data_a[2]&0x0c)>>2);
			  higrometro = ((data_a[2]&0x02)>>1);
			  
		  }
		  break;
		  
	  case 3: // encapsulo los bytes faltantes y envio a pc
		  TI2_Disable();
		  retrans = 0;
		  
		  binaria = (luz_in << 3);
		  palabra[1] = binaria|palabra[1];
		  binaria = (higrometro << 2);
		  palabra[1] = binaria|palabra[1];
		  
		  palabra[4] = corriente;
		  
		  binaria = ERROR & 0X0f;
		  palabra[7] = palabra[7]|binaria;
		  
		  AS1_SendBlock(palabra, num, &num);
		    		  
		  caudal = 0;
		  estado = 0;
		  
		  
	  break;
	  
  	  }  
	  
	  switch(estado_s){
	  case 0:
		  // ACTUALIZA LAS SALIDAS, ESPERA ENVIO DESDE PC
		  Bit3_PutVal(aire);
		  PWM1_SetRatio8(luz_pwm);
		  PWM2_SetRatio8(adc0); //prueba dimmer
 
		  break;
	  case 1:
		  // DESENCAPSULO LA TRAMA ENVIADA DESDE LA PC
		  luz_pwm = data_pc[1];
		  aire = data_pc[2]&0x01;
		  riego = (data_pc[2]&0x02)>>1;
		  estado_s = 0;
		  
		  break;
	  }
    }
  
  

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale HCS08 series of microcontrollers.
**
** ###################################################################
*/
